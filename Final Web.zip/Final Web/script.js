// ====================================================================
// NAVIGATION AND SCROLL FUNCTIONALITY
// ====================================================================

// Mobile menu toggle
const hamburger = document.querySelector('.hamburger');
const navMenu = document.querySelector('.nav-menu');
if (hamburger) {
    hamburger.addEventListener('click', () => {
        hamburger.classList.toggle('active');
        navMenu.classList.toggle('active');
    });
}

// Close mobile menu when clicking on a link
document.querySelectorAll('.nav-link').forEach(n => n.addEventListener('click', () => {
    if (hamburger && navMenu) {
        hamburger.classList.remove('active');
        navMenu.classList.remove('active');
    }
}));

// Smooth scrolling for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        // Only smooth scroll if the anchor is on the same page
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            e.preventDefault();
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Active navigation link highlighting
window.addEventListener('scroll', () => {
    let current = '';
    const sections = document.querySelectorAll('section');
    sections.forEach(section => {
        const sectionTop = section.offsetTop;
        if (pageYOffset >= (sectionTop - 200)) {
            current = section.getAttribute('id');
        }
    });
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === `#${current}`) {
            link.classList.add('active');
        }
    });
});

// ====================================================================
// DARK MODE FUNCTIONALITY
// ====================================================================

function toggleTheme() {
    const body = document.body;
    const themeToggle = document.querySelector('.theme-toggle i');

    if (body.getAttribute('data-theme') === 'dark') {
        body.removeAttribute('data-theme');
        themeToggle.classList.remove('fa-sun');
        themeToggle.classList.add('fa-moon');
        localStorage.setItem('theme', 'light');
    } else {
        body.setAttribute('data-theme', 'dark');
        themeToggle.classList.remove('fa-moon');
        themeToggle.classList.add('fa-sun');
        localStorage.setItem('theme', 'dark');
    }
}

// Load saved theme on page load
document.addEventListener('DOMContentLoaded', function() {
    const savedTheme = localStorage.getItem('theme');
    const themeToggle = document.querySelector('.theme-toggle i');
    if (savedTheme === 'dark') {
        document.body.setAttribute('data-theme', 'dark');
        if (themeToggle) {
            themeToggle.classList.remove('fa-moon');
            themeToggle.classList.add('fa-sun');
        }
    }
});

// ====================================================================
// EXPERIENCE TIMELINE TAB FUNCTIONALITY (NEW TIMELINE UI)
// ====================================================================
function switchExpTab(event, tabName) {
  document.querySelectorAll('.timeline').forEach(tl => tl.style.display = "none");
  document.getElementById(tabName).style.display = "block";
  document.querySelectorAll('.exp-tab').forEach(btn => btn.classList.remove('active'));
  event.target.closest('.exp-tab').classList.add('active');
}

// Only one skill group open at a time
function toggleSkillGroup(groupElement) {
    const groups = document.querySelectorAll('.skill-group');
    groups.forEach(group => {
        if (group === groupElement) {
            group.classList.toggle('active');
        } else {
            group.classList.remove('active');
        }
    });
}

// Add click event listeners to skill headers
document.addEventListener('DOMContentLoaded', function() {
    const skillHeaders = document.querySelectorAll('.skill-header');
    skillHeaders.forEach(header => {
        // Ensure no duplicate listeners are added by checking if one already exists (basic check)
        if (!header.dataset.listenerAdded) {
            header.addEventListener('click', function() {
                const groupElement = this.closest('.skill-group');
                toggleSkillGroup(groupElement);
            });
            header.dataset.listenerAdded = 'true'; // Mark to prevent duplicates
        }
    });

    // Open the first group by default only if no group is active initially
    const activeGroup = document.querySelector('.skill-group.active');
    if (!activeGroup) {
        const firstGroup = document.querySelector('.skill-group');
        if (firstGroup) {
            firstGroup.classList.add('active');
        }
    }
});

// ====================================================================
// ANIMATIONS AND SCROLL EFFECTS
// ====================================================================

// Intersection Observer for animations
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};
const observer = new IntersectionObserver(function(entries) {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

document.addEventListener('DOMContentLoaded', function() {
    // Animate timeline items (for both columns in new timeline)
    const timelineItems = document.querySelectorAll('.exp-timeline-item, .timeline-item');
    timelineItems.forEach(item => {
        item.style.opacity = '0';
        item.style.transform = 'translateY(20px)';
        item.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(item);
    });

    // Animate project cards
    const projectCards = document.querySelectorAll('.project-card');
    projectCards.forEach((card, index) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(30px)';
        card.style.transition = `opacity 0.6s ease ${index * 0.1}s, transform 0.6s ease ${index * 0.1}s`;
        observer.observe(card);
    });

    // Animate service cards
    const serviceCards = document.querySelectorAll('.service-card');
    serviceCards.forEach((card, index) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(30px)';
        card.style.transition = `opacity 0.6s ease ${index * 0.1}s, transform 0.6s ease ${index * 0.1}s`;
        observer.observe(card);
    });

    // Animate skill progress bars
    const skillBars = document.querySelectorAll('.skill-progress');
    skillBars.forEach(bar => {
        const width = bar.style.width;
        bar.style.width = '0%';
        setTimeout(() => {
            bar.style.width = width;
        }, 500);
    });
});

// ====================================================================
// FORM HANDLING
// ====================================================================

const contactForm = document.querySelector('.contact-form form');
if (contactForm) {
    contactForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        // Get form data
        const formData = new FormData(this);
        const name = formData.get('name');
        const email = formData.get('email');
        const subject = formData.get('subject');
        const message = formData.get('message');
        
        // Simple validation
        if (!name || !email || !subject || !message) {
            alert('Please fill in all fields.');
            return;
        }
        
        // Email validation
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            alert('Please enter a valid email address.');
            return;
        }

        // Get the submit button
        const submitButton = this.querySelector('button[type="submit"]');
        const originalButtonText = submitButton ? submitButton.innerHTML : '';

        try {
            if (submitButton) {
                submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';
                submitButton.disabled = true;
            }

            // Add to Firestore
            await db.collection('contacts').add({
                name: name,
                email: email,
                subject: subject,
                message: message,
                timestamp: firebase.firestore.FieldValue.serverTimestamp()
            });

            // Show custom success message
            const successMsg = document.getElementById('contact-success');
            if (successMsg) {
                successMsg.style.display = 'flex';
                setTimeout(() => {
                    successMsg.style.display = 'none';
                }, 4000);
            }
            this.reset();
        } catch (error) {
            console.error('Error submitting form:', error);
            alert('Sorry, there was an error sending your message. Please try again later.');
        } finally {
            if (submitButton) {
                submitButton.innerHTML = originalButtonText;
                submitButton.disabled = false;
            }
        }
    });
}

// ====================================================================
// SCROLL TO TOP FUNCTIONALITY
// ====================================================================

const scrollToTopBtn = document.createElement('button');
scrollToTopBtn.innerHTML = '<i class="fas fa-arrow-up"></i>';
scrollToTopBtn.setAttribute('class', 'scroll-to-top');
scrollToTopBtn.style.cssText = `
    position: fixed;
    bottom: 20px;
    right: 20px;
    width: 50px;
    height: 50px;
    border-radius: 50%;
    background: var(--primary-color);
    color: white;
    border: none;
    cursor: pointer;
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s ease;
    z-index: 1000;
    box-shadow: 0 4px 20px rgba(139, 92, 246, 0.3);
`;
document.body.appendChild(scrollToTopBtn);

window.addEventListener('scroll', () => {
    if (window.pageYOffset > 300) {
        scrollToTopBtn.style.opacity = '1';
        scrollToTopBtn.style.visibility = 'visible';
    } else {
        scrollToTopBtn.style.opacity = '0';
        scrollToTopBtn.style.visibility = 'hidden';
    }
});
scrollToTopBtn.addEventListener('click', () => {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
});

// ====================================================================
// IMAGE FALLBACK HANDLING
// ====================================================================

document.querySelectorAll('img').forEach(img => {
    img.onerror = function() {
        this.style.display = 'none';
    }
});

// ====== YOUR Projects Data ======
const projects = [
  {
    title: "Automatic Number Plate Recognition",
    desc: "Advanced ANPR system using YOLOv8 for vehicle detection and EasyOCR for text recognition. Features real-time processing with vehicle tracking using SORT algorithm for traffic monitoring and security applications.",
    image: "https://th.bing.com/th/id/OIP.Kfcjluks10k5n4XErbNw3wHaHa?rs=1&pid=ImgDetMain",
    stars: 8,
    btn: { text: "View Code", url: "https://github.com/deepkakadiya7/Project-1_Automatic-number-plate-recognition-" },
  },
  {
    title: "Movie Recommender System",
    desc: "Content-based movie recommendation web app built with Streamlit. Uses cosine similarity on movie metadata to suggest top 5 similar movies with an intuitive, responsive interface.",
    image: "https://th.bing.com/th/id/OIP.0u2ynz-XDDaq3suwHtC7eQHaEK?rs=1&pid=ImgDetMain",
    stars: 7,
    btn: { text: "View Code", url: "https://github.com/deepkakadiya7/-Movie-Recommender-System" },
  },
  {
    title: "Warehouse Autobots Simulation",
    desc: "Intelligent autonomous robot control system for warehouse operations. Features collision avoidance, parallel movement coordination, and efficient pathfinding in a grid-based environment.",
    image: "https://th.bing.com/th/id/OIP.dG9WsXhBYOWMqejgkjr8-wHaE7?rs=1&pid=ImgDetMain",
    stars: 5,
    btn: { text: "View Code", url: "https://github.com/deepkakadiya7/TheWarehouse-Autobots-Dilemma" },
  },
  {
    title: "Virtual Calculator with Computer Vision",
    desc: "Gesture-controlled calculator using hand tracking technology. Detects finger movements through webcam to perform arithmetic operations without physical interaction.",
    image: "https://photos5.appleinsider.com/gallery/59243-120937-PCalc-and-HomeUI-xl.jpg",
    stars: 5,
    btn: { text: "View Code", url: "https://github.com/deepkakadiya7/Virtual-Calculator-Computer-vision-" },
  },
  {
    title: "Smart Car Parking Counter",
    desc: "Computer vision system for monitoring parking spaces in real-time. Automatically detects and counts available parking spots from video feeds with visual status indicators.",
    image: "https://www.kyosis.com/wp-content/uploads/2018/12/AdobeStock_237845201.jpeg",
    stars: 8,
    btn: { text: "View Code", url: "https://github.com/dhairya150805/Car-Parking-Counter" },
  },
];

// ==== Carousel Logic ====
let projectIndex = 0;
const projectCarouselContent = document.querySelector(".carousel-content");
const carouselDotsContainer = document.querySelector(".carousel-dots");
const projectCards = []; // To store references to the created project card elements

// Create and append project cards based on the projects data
function initializeProjects() {
    if (!projectCarouselContent || !projects || projects.length === 0) return;

    projectCarouselContent.innerHTML = ''; // Clear existing content
    projectCards.length = 0; // Clear the array

    projects.forEach((p, index) => {
        const projectCard = document.createElement('div');
        projectCard.classList.add('project-card');
        projectCard.dataset.index = index; // Add data attribute for index

        projectCard.innerHTML = `
            <div class="project-image-container">
                <img src="${p.image}" alt="${p.title}" onerror="this.style.display='none'; this.closest('.project-image-container').innerHTML = '<div class=\'project-fallback\'><i class=\'fas fa-code\'></i></div>';" />
                <div class="project-fallback"><i class="fas fa-code"></i></div>
            </div>
            <div class="project-info">
                <div class="project-title">${p.title}</div>
                <div class="project-desc">${p.desc}</div>
                <div class="project-meta">
                    <i class="fas fa-star"></i> ${p.stars}
                </div>
                <a class="project-btn" href="${p.btn.url}" target="_blank">${p.btn.text} <i class="fas fa-arrow-right"></i></a>
            </div>
        `;
        projectCarouselContent.appendChild(projectCard);
        projectCards.push(projectCard); // Store reference
    });
}

function updateProjectDisplay() {
    if (projectCards.length === 0) return;

    projectCards.forEach((card, index) => {
        card.classList.remove('active', 'prev');
        // Determine the position relative to the current active project
        let offset = index - projectIndex;
        if (offset > projects.length / 2) { // Handle wrap around to the left
            offset -= projects.length;
        } else if (offset < -projects.length / 2) { // Handle wrap around to the right
            offset += projects.length;
        }

        if (index === projectIndex) {
            card.classList.add('active');
        } else if (index === (projectIndex - 1 + projectCards.length) % projectCards.length) {
            card.classList.add('prev'); // Mark the previous card for potential styling
        }

        // Position cards using transform for smooth sliding effect
        // Non-active cards are moved off-screen, active card is at 0
        card.style.transform = `translateX(${offset * 100}%)`;
        card.style.opacity = offset === 0 ? 1 : 0; // Only active card is visible
        card.style.position = 'absolute'; // Position absolutely within carousel-content
        card.style.top = 0;
        card.style.left = 0;
        card.style.width = '100%';
        card.style.zIndex = offset === 0 ? 1 : 0; // Bring active card to front
    });

    // Update dots
    if (carouselDotsContainer) {
        let dotsHTML = "";
        for (let i = 0; i < projects.length; i++) {
            dotsHTML += `<div class="dot${i === projectIndex ? " active" : ""}" onclick="goToProject(${i})"></div>`;
        }
        carouselDotsContainer.innerHTML = dotsHTML;
    }
}

function prevProject() {
    projectIndex = (projectIndex - 1 + projects.length) % projects.length;
    updateProjectDisplay();
}

function nextProject() {
    projectIndex = (projectIndex + 1) % projects.length;
    updateProjectDisplay();
}

function goToProject(idx) {
    projectIndex = idx;
    updateProjectDisplay();
}

// Initialize carousel on page load
document.addEventListener("DOMContentLoaded", function() {
    initializeProjects();
    updateProjectDisplay();

    // Add event listeners for carousel arrows
    const prevArrow = document.querySelector('.carousel-arrow.left');
    const nextArrow = document.querySelector('.carousel-arrow.right');
    if (prevArrow) prevArrow.addEventListener('click', prevProject);
    if (nextArrow) nextArrow.addEventListener('click', nextProject);
});

// ====================================================================
// INITIALIZATION
// ====================================================================

document.addEventListener('DOMContentLoaded', function() {
    console.log('Portfolio website loaded successfully!');
    const requiredElements = [
        '.navbar',
        '.hero',
        '.about',
        '.skills',
        '.projects',
        '.contact'
    ];
    requiredElements.forEach(selector => {
        if (!document.querySelector(selector)) {
            console.warn(`Element ${selector} not found`);
        }
    });
});
