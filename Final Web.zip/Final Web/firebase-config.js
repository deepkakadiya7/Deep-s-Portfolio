// Firebase configuration
const firebaseConfig = {
    // Replace these with your Firebase project configuration
    apiKey: "AIzaSyArszLXD...your real key...",
    authDomain: "my-web-66a28.firebaseapp.com",
    projectId: "my-web-66a28",
    storageBucket: "my-web-66a28.appspot.com",
    messagingSenderId: "137978440748",
    appId: "1:137978440748:web:7c4e2b6842475f7fb9f589",
    measurementId: "G-DCDNCQP22H"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

// Initialize Firestore
const db = firebase.firestore(); 